// Function to validate the registration form
function validateRegistrationForm() {
    var firstName = document.forms["registrationForm"]["first_name"].value;
    var lastName = document.forms["registrationForm"]["last_name"].value;
    var email = document.forms["registrationForm"]["email"].value;
    var password = document.forms["registrationForm"]["password"].value;

    if (firstName === "" || lastName === "" || email === "" || password === "") {
        alert("All fields are required");
        return false;
    }
    
    // You can add more validation rules here

    return true;
}

// Function to validate the login form
function validateLoginForm() {
    var username = document.forms["loginForm"]["username"].value;
    var password = document.forms["loginForm"]["password"].value;

    if (username === "" || password === "") {
        alert("Both username and password are required");
        return false;
    }

    // You can add more validation rules for the login form here

    return true;
}
