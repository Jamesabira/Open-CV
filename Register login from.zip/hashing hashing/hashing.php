<?php

/**
 * Generates a combined hash of the given data using SHA-256 and SHA-3.
 *
 * This function is more secure than using either SHA-256 or SHA-3 alone, as it is more resistant to collision attacks.
 *
 * @param string $data The data to hash.
 * @param int $hash_length The desired hash length in bits. Must be a positive integer.
 * @param bool $debug Whether to enable debugging.
 * @return string The combined hash of the data.
 * @throws Exception If the hash length is invalid or the hash could not be generated successfully.
 */
function combined_hash($data, $hash_length = 512, $debug = false): string
{
    // Register an error handler to catch any errors that occur while generating the hash.
    set_error_handler(function ($errno, $errstr, $errfile, $errline) {
        throw new Exception('Failed to generate hash: ' . $errstr);
    });

    try {
        // Validate the hash length.
        if ($hash_length <= 0) {
            throw new Exception('Invalid hash length.');
        }

        // Calculate the SHA-256 hash of the data.
        $sha256_hash = hash('sha256', $data);

        // Calculate the SHA-3 hash of the SHA-256 hash.
        $sha3_hash = hash('sha3-256', $sha256_hash);

        // Combine the SHA-256 and SHA-3 hashes into a single hash.
        $combined_hash = substr($sha256_hash . $sha3_hash, 0, $hash_length);

        // Check if the hash was generated successfully.
        if (!is_string($combined_hash) || strlen($combined_hash) !== $hash_length) {
            throw new Exception('Failed to generate hash.');
        }

        if ($debug) {
            // Log the hash generation steps.
            error_log('SHA-256 hash: ' . $sha256_hash);
            error_log('SHA-3 hash: ' . $sha3_hash);
            error_log('Combined hash: ' . $combined_hash);
        }

        return $combined_hash;
    } finally {
        // Restore the default error handler.
        restore_error_handler();
    }
}
